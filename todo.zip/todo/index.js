const express = require("express");
const app = express();

// srver listing on port through th e env file 
// load config file from env file 
require("dotenv").config();
const PORT =process.env.PORT || 4000;
// middleware to parse json request body
// adding parser
app.use(express.json());

// import routes from todo api 
const todoRoutes = require("./routes/todo");
// mount the api routes 
app.use("/api/v1",todoRoutes);
// server run
app.listen(PORT,()=>{
    console.log(`server started successfully at ${PORT}`);
})
// connect to db server
const dbConnect =require("./config/database");
dbConnect();
// deafault routes
app.get("/",(req,res)=>{
   res.send(`<h1> This is homepage babs</h1>`);
})